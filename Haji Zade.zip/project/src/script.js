function validateRequired(fieldValue) {
    if (fieldValue === '') {
        return false
    }else{
        return true
    }
}

document.getElementById('submit').addEventListener('click', function() {
    let nameValue = document.getElementById('name').value;
    let emailValue = document.getElementById('email').value;
    let passwordValue = document.getElementById('password').value;

    if(validateRequired(nameValue) || validateRequired(emailValue) || validateRequired(passwordValue)){
        alert('Done! The data are currect.')
    }else{
        alert('The data are not currect.')
    }
});
